import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import accuracy_score, recall_score, f1_score
from collections import Counter
import pandas as pd
from nltk.tokenize import word_tokenize
import nltk

# Download the required NLTK models
nltk.download('punkt')

# Define a function to load the dataset
def load_dataset(file_path):
    return pd.read_csv(file_path, sep='\t')

# Load the datasets
df_train = load_dataset('enhanced_dataset1.tsv')
df_test = load_dataset('enhanced_dataset2.tsv')

# Tokenize the text and build a Counter of words
counter = Counter()
for text in df_train['text']:
    tokens = word_tokenize(text.lower())  # Tokenize and convert to lower case
    counter.update(tokens)

# Create the vocabulary by filtering out tokens that appear less than twice
min_freq = 2
vocab = {token: index + 2 for index, (token, count) in enumerate(counter.items()) if count >= min_freq}
vocab['<unk>'] = 0  # Add a default value for unknown words
vocab['<pad>'] = 1  # Add a padding token

# Function to convert text to numericalized tokens
def numericalize(text):
    return [vocab.get(token, vocab['<unk>']) for token in word_tokenize(text.lower())]

# Convert texts to sequences of indices
df_train['text_numerical'] = df_train['text'].apply(numericalize)
df_test['text_numerical'] = df_test['text'].apply(numericalize)

# Define the Dataset class
class TextDataset(Dataset):
    def __init__(self, texts, labels):
        self.texts = texts
        self.labels = labels

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        return torch.tensor(self.texts[idx], dtype=torch.long), torch.tensor(self.labels[idx], dtype=torch.long)

# Define the Att-LSTM model
class AttLSTM(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim):
        super(AttLSTM, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=vocab['<pad>'])
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)
        self.attention_layer = nn.Linear(hidden_dim, 1)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, text):
        embedded = self.embedding(text)
        lstm_output, (hidden, cell) = self.lstm(embedded)
        attention_weights = torch.softmax(self.attention_layer(lstm_output).squeeze(2), dim=1)
        weighted_representation = torch.mul(lstm_output, attention_weights.unsqueeze(2)).sum(dim=1)
        out = self.fc(weighted_representation)
        return out

# Define the training function
def train(model, data_loader, optimizer, criterion):
    model.train()
    total_loss = 0
    for texts, labels in data_loader:
        optimizer.zero_grad()
        predictions = model(texts)
        loss = criterion(predictions, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(data_loader)

# Define the evaluation function
def evaluate(model, data_loader, criterion):
    model.eval()
    total_loss = 0
    all_predictions = []
    all_labels = []
    with torch.no_grad():
        for texts, labels in data_loader:
            predictions = model(texts)
            loss = criterion(predictions, labels)
            total_loss += loss.item()
            all_predictions.extend(predictions.argmax(dim=1).cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    return (total_loss / len(data_loader),
            accuracy_score(all_labels, all_predictions),
            recall_score(all_labels, all_predictions, average='macro'),
            f1_score(all_labels, all_predictions, average='macro'))

# Prepare the data
train_dataset = TextDataset(df_train['text_numerical'].tolist(), df_train['polarity'].tolist())
test_dataset = TextDataset(df_test['text_numerical'].tolist(), df_test['polarity'].tolist())
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32)

# Model parameters
VOCAB_SIZE = len(vocab)
EMBEDDING_DIM = 100
HIDDEN_DIM = 128
OUTPUT_DIM = 3  # Assuming polarity has 3 unique values

# Instantiate the model
model = AttLSTM(VOCAB_SIZE, EMBEDDING_DIM, HIDDEN_DIM, OUTPUT_DIM)

# Define the optimizer and criterion
optimizer = torch.optim.Adam(model.parameters())
criterion = nn.CrossEntropyLoss()

# Training loop
for epoch in range(10):
    train_loss = train(model, train_loader, optimizer, criterion)
    test_loss, test_acc, test_recall, test_f1 = evaluate(model, test_loader, criterion)
    print(f'Epoch: {epoch+1}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}, '
          f'Accuracy: {test_acc:.4f}, Recall: {test_recall:.4f}, F1: {test_f1:.4f}')
