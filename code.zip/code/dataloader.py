import torch
from torch.utils.data import DataLoader, Dataset
import os
import numpy as np
import random
import json
import pandas as pd
def get_word_vec(base_dir):
    word_path = base_dir + '/' + 'glove.6B.50d.json'
    if not os.path.exists(word_path):
        print("[Error] Data file does not exists !")
        assert 0
    word_vec = json.load(open(word_path, 'r'))
    word_total = len(word_vec)
    word_dim = len(word_vec[0]['vec'])
    word_vec_mat = np.zeros((word_total, word_dim), dtype=np.float32)
    word2id = {}
    for cur_id, word in enumerate(word_vec):
        w = word['word'].lower()
        word2id[w] = cur_id
        word_vec_mat[cur_id, :] = word['vec']
        word_vec_mat[cur_id] =word_vec_mat[cur_id] / np.sqrt((np.sum(word_vec_mat[cur_id] ** 2)))

    UNK = word_total
    PAD = word_total + 1
    word2id['UNK'] = UNK
    word2id['PAD'] = PAD
    return word2id, word_vec_mat

def process_data(base_dir, data_path, max_lenth =100):
    word2id, word_vec_mat = get_word_vec(base_dir)
    # word_path = base_dir + '/' + 'glove.6B.50d.json'
    data_path = base_dir + '/' + data_path

    if not os.path.exists(data_path):
        print("[Error] Data file does not exists !")
        assert 0
    train_data = pd.read_csv(data_path, sep='\t')
    content = []
    def tokenize(tokens, max_length):
        idx_tokens = []
        mask = []
        for tk in tokens:
            tk = tk.lower()
            if tk in word2id:
                idx_tokens.append(word2id[tk])
            else:
                idx_tokens.append(word2id['UNK'])
        mask += len(idx_tokens) * [1]
        if len(idx_tokens) < max_length:
            mask += (max_length - len(idx_tokens)) * [0]
            idx_tokens += (max_length - len(idx_tokens)) * [word2id['PAD']]

        else:
            idx_tokens = idx_tokens[:max_length]
            mask = mask[:max_length]

        assert len(idx_tokens) == len(mask) == max_length

        return idx_tokens, mask
    for id in range(train_data.__len__()):
        instance = {}
        ins = train_data.iloc[id]
        text = ins['text']
        aspect = ins['aspect']
        label = ins['polarity']
        instance['tokens'], instance['t_mask'] = tokenize(text, max_lenth)
        instance['aspect'], instance['a_mask']  = tokenize(aspect, 10)
        instance['label'] = int(label) + 1
        content.append(instance)
    return content

class data_set(Dataset):
    def __init__(self, data):
        self.data = data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

    def collate_fn(self, data):
        label = torch.tensor([item['label'] for item in data])
        aspect = [torch.tensor(item['aspect']) for item in data]
        amasks = [torch.tensor(item['a_mask']) for item in data]
        tokens = [torch.tensor(item['tokens']) for item in data]
        tmasks = [torch.tensor(item['t_mask']) for item in data]
        return (label, tokens, tmasks, aspect, amasks)

def data_loader(args, data, shuffle=True, drop_last = False, batch_size=None):
    dataset = data_set(data)
    if batch_size == None:
        batch_size = min(args.batch_size_per_step, len(data))
    else:
        batch_size = min(batch_size, len(data))

    data_loader = DataLoader(
        dataset = dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        pin_memory=False,
        num_workers=args.num_workers,
        collate_fn=dataset.collate_fn,
        drop_last=drop_last
    )
    return data_loader

def get_data_loader(args):
    train_data = process_data(args.base_dir, args.train_path, args.max_length)
    test_data = process_data(args.base_dir, args.test_path, args.max_length)
    train_dataloader = data_loader(args, train_data)
    test_dataloader = data_loader(args, test_data)
    return train_dataloader, test_dataloader

