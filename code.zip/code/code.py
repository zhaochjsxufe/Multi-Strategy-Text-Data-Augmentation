
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
from sklearn.metrics import accuracy_score, recall_score, f1_score
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from collections import Counter
import itertools
from torch.nn.utils.rnn import pad_sequence
# File paths
train_data_path = ''  # Update with your train dataset path
test_data_path = ''    # Update with your test dataset path
glove_path = 'glove.6B.50d.txt'    # Update with your GloVe embeddings path

# Load data
train_df = pd.read_csv(train_data_path, sep='\t', usecols=['text', 'polarity'])
print(train_df)
test_df = pd.read_csv(test_data_path, sep='\t', usecols=['text', 'polarity'])

# Preprocessing
def preprocess_data(df):
    # 将情感极性映射为非负整数
    polarity_mapping = {0: 0, 1: 1, -1: 2}
    df['polarity'] = df['polarity'].map(polarity_mapping)
    return df

# Load data
train_df = pd.read_csv(train_data_path, sep='\t', usecols=['text', 'polarity'])
test_df = pd.read_csv(test_data_path, sep='\t', usecols=['text', 'polarity'])

# Check for NaN values and drop rows with NaN in 'text' column
train_df = train_df.dropna(subset=['text'])
test_df = test_df.dropna(subset=['text'])

train_df = preprocess_data(train_df)
test_df = preprocess_data(test_df)
print("Number of samples in training data:", len(train_df))
# Load GloVe embeddings
def load_glove_embeddings(path, word_index, embedding_dim=50):
    with open(path, 'r', encoding='utf8') as f:
        embeddings = {}
        for line in f:
            values = line.split()
            word = values[0]
            vector = np.asarray(values[1:], dtype='float32')
            embeddings[word] = vector

    embedding_matrix = np.zeros((len(word_index) + 1, embedding_dim))
    for word, i in word_index.items():
        embedding_vector = embeddings.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix

# Tokenization and Vocabulary Creation
tokenizer = lambda x: x.split()
vocab = Counter(itertools.chain(*train_df['text'].apply(tokenizer)))
word_index = {word: i + 1 for i, (word, _) in enumerate(vocab.items())}

# Load GloVe embeddings
embedding_matrix = load_glove_embeddings(glove_path, word_index)


class TextDataset(Dataset):
    def __init__(self, dataframe, word_index):
        self.dataframe = dataframe
        self.word_index = word_index

    def __len__(self):
        return len(self.dataframe)  # 返回数据集的长度

    def __getitem__(self, idx):
        text = self.dataframe.iloc[idx]['text']
        label = self.dataframe.iloc[idx]['polarity']
        tokens = [self.word_index.get(word, 0) for word in text.split()]
        return torch.tensor(tokens, dtype=torch.long), len(tokens), torch.tensor(label, dtype=torch.long)

# 确保 collate_fn 也正确处理
def collate_fn(batch):
    batch.sort(key=lambda x: x[1], reverse=True)
    sequences, lengths, labels = zip(*batch)
    sequences_padded = pad_sequence(sequences, batch_first=True)
    return sequences_padded, torch.tensor(lengths, dtype=torch.long), torch.tensor(labels, dtype=torch.long)

# Data Loaders
train_dataset = TextDataset(train_df, word_index)
test_dataset = TextDataset(test_df, word_index)
# train_dataset = TextDataset(train_df, word_index)

# 再次检查 train_dataset 的长度
print("Number of samples in TextDataset:", len(train_dataset))
# Update Data Loaders
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, collate_fn=collate_fn)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False, collate_fn=collate_fn)

# Att-LSTM Model
class AttLSTM(nn.Module):
    def __init__(self, embedding_matrix, hidden_size=128, num_classes=3):
        super(AttLSTM, self).__init__()
        self.hidden_size = hidden_size  # Save hidden_size as a class attribute
        self.embedding = nn.Embedding.from_pretrained(torch.tensor(embedding_matrix, dtype=torch.float))
        self.lstm = nn.LSTM(embedding_matrix.shape[1], self.hidden_size, batch_first=True, bidirectional=True)
        self.fc = nn.Linear(self.hidden_size * 2, num_classes)

    def attention_net(self, lstm_output, final_state):
        hidden = final_state.view(-1, self.hidden_size * 2, 1)  # Use self.hidden_size here
        attn_weights = torch.bmm(lstm_output, hidden).squeeze(2)
        soft_attn_weights = torch.nn.functional.softmax(attn_weights, 1)
        new_hidden_state = torch.bmm(lstm_output.transpose(1, 2), soft_attn_weights.unsqueeze(2)).squeeze(2)
        return new_hidden_state

    def forward(self, x, lengths):
        embeds = self.embedding(x)
        packed_input = pack_padded_sequence(embeds, lengths, batch_first=True, enforce_sorted=False)
        packed_output, (final_hidden_state, final_cell_state) = self.lstm(packed_input)
        lstm_out, _ = pad_packed_sequence(packed_output, batch_first=True)
        attn_output = self.attention_net(lstm_out, final_hidden_state)
        logits = self.fc(attn_output)
        return logits


# Model Initialization
model = AttLSTM(embedding_matrix)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training Loop
for epoch in range(20):  # Number of epochs
    model.train()
    for texts, lengths, labels in train_loader:
        optimizer.zero_grad()
        outputs = model(texts, lengths)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

    # Evaluate on the test set
    model.eval()
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for sequences_padded, lengths, labels in test_loader:
        # for texts, labels in test_loader:
        #     outputs = model(texts)
            outputs = model(sequences_padded, lengths)
            _, predicted = torch.max(outputs, 1)
            all_preds.extend(predicted.numpy())
            all_labels.extend(labels.numpy())

    # Calculate metrics
    accuracy = accuracy_score(all_labels, all_preds)
    recall = recall_score(all_labels, all_preds, average='macro')
    f1 = f1_score(all_labels, all_preds, average='macro')
    print(f'Epoch {epoch+1}: Accuracy: {accuracy}, Recall: {recall}, F1 Score: {f1}')

# Note: Adjust the batch size, learning rate, number of epochs, and model architecture as needed.
