import torch.nn as nn
import torch
import torch.nn.functional as F
class Embedding(nn.Module):
    def __init__(self, word_vec_mat, embedding_dim=50):
        super(Embedding, self).__init__()
        unk = torch.zeros(1, embedding_dim)
        blk = torch.zeros(1, embedding_dim)
        word_vec_mat = torch.from_numpy(word_vec_mat)
        self.word_embedding = nn.Embedding(word_vec_mat.shape[0] + 2, embedding_dim,
                                           padding_idx=word_vec_mat.shape[0] + 1)
        self.word_embedding.weight.data.copy_(torch.cat((word_vec_mat, unk, blk), 0))

    def forward(self, inputs):
        word_embedding = self.word_embedding(inputs)
        return word_embedding

class ATAE_LSTM(nn.Module):
    def __init__(self, args, word_vec_mat):
        super(ATAE_LSTM, self).__init__()
        self.args = args
        self.embeddings = Embedding(word_vec_mat, args.embedding_dim)
        self.lstm = nn.LSTM(input_size=2 * args.embedding_dim,
                            hidden_size=args.num_hiddens,
                            num_layers=args.num_layers,
                            batch_first=True,
                            bidirectional=True)
        self.wh = nn.Parameter(torch.Tensor(args.num_hiddens * 2, args.num_hiddens * 2))
        self.wv = nn.Parameter(torch.Tensor(args.embedding_dim, args.embedding_dim))
        self.omega = nn.Parameter(
            torch.Tensor(1, args.embedding_dim + args.num_hiddens*2))
        self.wp = nn.Parameter(torch.Tensor(args.num_hiddens * 2, args.num_hiddens * 2))
        self.wx = nn.Parameter(torch.Tensor(args.num_hiddens * 2, args.num_hiddens * 2))
        self.ws = nn.Parameter(torch.Tensor(3, args.num_hiddens * 2))
        nn.init.uniform_(self.wh, -0.1, 0.1)
        nn.init.uniform_(self.wv, -0.1, 0.1)
        nn.init.uniform_(self.omega, -0.1, 0.1)
        nn.init.uniform_(self.wp, -0.1, 0.1)
        nn.init.uniform_(self.wx, -0.1, 0.1)
        nn.init.uniform_(self.ws, -0.1, 0.1)
        self.bs = nn.Parameter(torch.zeros((3, 1)))

    def forward(self, text, aspect):
        seq_len = text.size(1)
        e1 = self.embeddings(text)
        # e1 形状是(batch_size,seq_len, embedding_dim)
        e2 = self.embeddings(aspect).mean(1).unsqueeze(1).expand(-1, e1.size(1), -1)

        wv = torch.cat((e1, e2), dim=2)
        # e.g.
        # wv torch.Size([batch_size,seq_len,2*embedding_dim])

        out, (h, c) = self.lstm(wv)  # output, (h, c)
        # out形状是(batch_size,seq_len, 2 * num_hiddens)
        # h形状是(num_layers * num_directions, batch_size, 2*num_hiddens)
        H = out.permute(0, 2, 1)
        # H形状是(batch_size,2 * num_hiddens,seq_len)
        # print(H.shape)
        # print(self.wh.shape)

        Wh_H = torch.matmul(self.wh, H)
        # wh 形状是(2*num_hiddens, 2*num_hiddens)
        # wh_H 形状是(batch_size, 2*num_hiddens, seq_len)
        # print('Wh_H: ', Wh_H.shape)
        Wv_Va_eN = torch.matmul(self.wv, e2.permute(0, 2,1))
        # Wv 形状是(seq_len, seq_len) embedding_dim=2*num_hiddens
        # Wv_Va_eN 形状是(batch_size, embedding_dim, seq_len)
        # print('Wv_Va_eN: ', Wv_Va_eN.shape)
        vh = torch.cat((Wh_H, Wv_Va_eN), dim=1)
        # vh 形状是(batch_size, 2*embedding_dim, seq_len)
        # print('vh: ', vh.shape)

        M = torch.tanh(vh)
        # M 形状是(batch_size, 2*embedding_dim, seq_len)
        # print('M: ', M.shape)

        alpha = F.softmax(torch.matmul(self.omega, M), dim=2)
        # omega 形状为(1, 2*embedding_dim))
        # alpha 形状为(batch_size, 1, seq_len)

        r = torch.matmul(H, alpha.permute(0, 2, 1))
        # H形状是(batch_size,2 * num_hiddens,seq_len)
        # r 形状为(batch_size,2*num_hiddens,1)
        # print('r: ', r.shape)

        h_star = torch.tanh(
            torch.matmul(self.wp, r) +
            torch.matmul(self.wx, torch.unsqueeze(H[:, :, -1], 2)))
        # h_star形状是(batch_size,2 * num_hiddens,1)
        # print('h_star: ', h_star.shape)

        y = torch.matmul(self.ws, h_star) + self.bs  # 不需要手动求softmax
        # y 形状(batch_size,3,1)

        y = y.reshape([-1, 3])
        # y 形状(batch_size,3)
        # ws 形状(3, 2*num_hiddens)
        # print('y: ', y.shape)

        return y