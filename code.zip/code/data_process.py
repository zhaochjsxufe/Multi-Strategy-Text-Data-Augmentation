import xml.etree.cElementTree as ET
import pandas as pd
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
nltk.download('punkt')
path = 'data/restaurants-train.xml'
tree = ET.parse(path)
root = tree.getroot()
print(root.tag)

print(root[0][0].text)
token=word_tokenize(root[0][0].text)
print(token)

from nltk.corpus import stopwords

stop_words = []
for w in ['!',',','.','?','-s','-ly','</s>','s','(',')',' ']:
    stop_words.append(w)
train = [w for w in token if w not in stop_words]

data = []
for sentence in root.findall('sentence'):
    text = sentence.find('text').text
    clean_text = [w for w in word_tokenize(text) if w not in stop_words]
    aspectCategories = sentence.find('aspectCategories')
    for aspectCategory in aspectCategories.findall('aspectCategory'):
        category = aspectCategory.get('category')
        polarity = aspectCategory.get('polarity')
        data.append((text, category, polarity))
data = np.random.permutation(data)

df = pd.DataFrame(data,columns=['text', 'aspect', 'polarity'])
df = df[df['polarity'].isin(['positive', 'negative', 'neutral'])]
df.groupby('aspect')['aspect'].count()
df['aspect'] = df['aspect'].replace('anecdotes/miscellaneous', 'anecdotes miscellaneous')
df['polarity'] = df['polarity'].map(
    {'positive': 1, 'neutral': 0, 'negative': -1})


df.to_csv('data/data.csv', sep=' ',index=0)
# print(df)
# print(df[df['text'].str.contains("miscellaneous")])


import numpy as np
import re
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

dataset = pd.read_csv('data/data.csv', sep=' ')

# 英文缩写替换
text_abbreviation = []
for item in dataset['text'].tolist():
    item = item.lower().replace("it's", "it is").replace("i'm", "i am").replace("he's", "he is").replace("she's", "she is")\
        .replace("we're", "we are").replace("they're", "they are").replace("you're", "you are").replace("that's", "that is")\
        .replace("this's", "this is").replace("can't", "can not").replace("don't", "do not").replace("doesn't", "does not")\
        .replace("we've", "we have").replace("i've", " i have").replace("isn't", "is not").replace("won't", "will not")\
        .replace("hasn't", "has not").replace("wasn't", "was not").replace("weren't", "were not").replace("let's", "let us")\
        .replace("couldn't", "could not")
    text_abbreviation.append(item)

# 删除标点符号、数字等其他字符
text_clear = []
for item in text_abbreviation:
    item = re.sub("[^a-zA-Z]", " ", item)
    text_clear.append(' '.join(item.split()))

processed_text = []
# 分词、词形归一化、删除停用词
for item in text_clear:
    words_token = word_tokenize(item)  # 分词
    words = [w for w in words_token if w not in stop_words]
    processed_text.append(' '.join(words))

df = pd.DataFrame({'text': processed_text,
                   'aspect': dataset['aspect'] ,
                   'polarity': dataset['polarity']})
print(df.head())

df.insert(0,'id',list(range(df.shape[0])))
print(df.head())

train = df[:int(0.7*len(data))]
test = df[int(0.7*len(data)):]
train.to_csv('data/train_laptop.tsv', sep='\t',index=0)
test.to_csv('data/test_laptop.tsv', sep='\t',index=0)

# corpus = pd.DataFrame(data=processed_text)
# corpus.to_csv('data/corpus.csv', header=0, index=0)
#
# from gensim.models import word2vec
#
# sentences = word2vec.LineSentence('data/corpus.csv')
# model = word2vec.Word2Vec(sentences, min_count=1)# 待考虑
# pairs = [
#     ('food', 'exceptional'),
#     ('fair', 'kitchen'),
# ]
# for w1, w2 in pairs:
#     print('%r\t%r\t%.2f' % (w1, w2,model.wv.similarity(w1, w2)))
#
#
# model.wv.save_word2vec_format('data/myvector.vector', binary=False)