import torch
import torch.nn as nn
import time
class framework(object):
    def __init__(self, args, train_loader, val_loader, test_loader):
        self.args = args
        self.train_iter = train_loader
        self.val_iter = val_loader
        self.test_iter = test_loader

    def evaluate_accuracy(self, test_iter, model):
        acc_sum, n = 0.0, 0
        with torch.no_grad():
            for batch_idx, batch in enumerate(test_iter):
                X1, X2, y = batch[1], batch[3], batch[0]
                X1 = torch.stack([x.to(self.args.device) for x in X1], dim=0)
                X2 = torch.stack([x.to(self.args.device) for x in X2], dim=0)
                y = y.to(self.args.device)
                # X1 = X1.permute(1, 0)
                # X2 = X2.permute(1, 0)
                if isinstance(model, torch.nn.Module):
                    model.eval()  # 评估模式, 这会关闭dropout
                    acc_sum += (model(X1, X2).argmax(dim=1) == y).float().sum().item()
                    model.train()  # 改回训练模式
                else:
                    if ('is_training'
                            in model.__code__.co_varnames):  # 如果有is_training这个参数
                        # 将is_training设置成False
                        acc_sum += (model(X1, X2, is_training=False).argmax(
                            dim=1) == y).float().sum().item()
                    else:
                        acc_sum += (model(
                            X1, X2).argmax(dim=1) == y).float().sum().item()
                n += y.shape[0]
        return acc_sum / n

    def train(self, model):
        num_epochs = self.args.num_epochs
        optimizer = torch.optim.Adam(model.parameters(), lr=self.args.lr)
        loss = nn.CrossEntropyLoss()
        batch_count = 0
        best_acc = 0
        for epoch in range(num_epochs):
            train_l_sum, train_acc_sum, n, start = 0.0, 0.0, 0, time.time()
            for batch_idx, batch in enumerate(self.train_iter):
                X1, X2, y = batch[1], batch[3], batch[0]
                X1 = torch.stack([x.to(self.args.device) for x in X1], dim=0)
                X2 = torch.stack([x.to(self.args.device) for x in X2], dim=0)
                y = y.to(self.args.device)
                # X1 = X1.permute(1, 0)
                # X2 = X2.permute(1, 0)
                y_hat = model(X1, X2)
                l = loss(y_hat, y)
                optimizer.zero_grad()
                l.backward()
                optimizer.step()
                train_l_sum += l.item()
                train_acc_sum += (y_hat.argmax(dim=1) == y).sum().item()
                n += y.shape[0]
                batch_count += 1
            test_acc = self.evaluate_accuracy(self.test_iter, model)
            if test_acc > best_acc:
                best_acc = test_acc
                torch.save(model.state_dict(), 'best_ckpt.pth')
            print(
                'epoch %d, loss %.4f, train acc %.3f, test acc %.3f, time %.1f sec'
                % (epoch + 1, train_l_sum / batch_count, train_acc_sum / n,
                   test_acc, time.time() - start))
        print('Best Acc:', best_acc)

    def test(self, model, ckpt=None):
        if ckpt is not None:
            model.load_state_dict(torch.load(ckpt))
        test_acc = self.evaluate_accuracy(self.test_iter, model)
        return test_acc