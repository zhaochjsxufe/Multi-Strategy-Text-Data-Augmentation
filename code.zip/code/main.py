from argparse import ArgumentParser
from dataloader import get_data_loader
from framework import framework
from dataloader import get_word_vec
from model import ATAE_LSTM
if __name__ == '__main__':
    parser = ArgumentParser(description='Sentiment Analysis (SA) ...')
    parser.add_argument('--max_length', default=150)
    parser.add_argument('--base_dir', default='./data')
    parser.add_argument('--train_path', default='train_2014laptop.tsv')
    parser.add_argument('--test_path', default='test_2014laptop.tsv')
    parser.add_argument('--num_workers', default=4)
    parser.add_argument('--batch_size_per_step', default=80)
    parser.add_argument('--embedding_dim', default=50)
    parser.add_argument('--num_hiddens', default=150)
    parser.add_argument('--num_layers', default=1)
    parser.add_argument('--lr', default=0.01)
    parser.add_argument('--num_epochs', default=40)
    parser.add_argument('--device', default='cpu')
    parser.add_argument('--status', default='train')
    parser.add_argument('--ckpt', default='best_ckpt.pth')
    args = parser.parse_args()
    word2id, word_vec_mat = get_word_vec(args.base_dir)
    train_dataloader, test_dataloder = get_data_loader(args=args)
    model = ATAE_LSTM(args, word_vec_mat).to(args.device)
    SAFramework = framework(args, train_dataloader, test_dataloder, test_dataloder)
    if args.status == 'train':
        SAFramework.train(model)
    else:
        test_acc = SAFramework.test(model, ckpt=args.ckpt)
        print('Test Accuracy:', test_acc)



