import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, recall_score, f1_score
from sklearn.model_selection import train_test_split

# File paths
train_data_path = ''  # Update with your train dataset path
test_data_path = ''    # Update with your test dataset path

# Load data
train_df = pd.read_csv(train_data_path, sep='\t', usecols=['text', 'polarity'])
test_df = pd.read_csv(test_data_path, sep='\t', usecols=['text', 'polarity'])

# Preprocessing
def preprocess_data(df):
    polarity_mapping = {0: 0, 1: 1, -1: 2}
    df['polarity'] = df['polarity'].map(polarity_mapping)
    return df

train_df = train_df.dropna(subset=['text'])
test_df = test_df.dropna(subset=['text'])

train_df = preprocess_data(train_df)
test_df = preprocess_data(test_df)

# Combine train and test sets for vectorization
combined_df = pd.concat([train_df, test_df])

# TF-IDF Vectorization
vectorizer = TfidfVectorizer(max_features=3000)
X = vectorizer.fit_transform(combined_df['text'])
y = combined_df['polarity']

# Splitting the combined data back into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=len(test_df), stratify=y)

# SVM Model
model = SVC(kernel='linear', C=1.0)

# Training the model
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Calculate metrics
accuracy = accuracy_score(y_test, y_pred)
recall = recall_score(y_test, y_pred, average='macro')
f1 = f1_score(y_test, y_pred, average='macro')
print(f'Accuracy: {accuracy}, Recall: {recall}, F1 Score: {f1}')
